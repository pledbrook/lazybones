println "hello ${name}"
println "\${bar} was unfiltered"