Sample Lazybones template just for testing.
